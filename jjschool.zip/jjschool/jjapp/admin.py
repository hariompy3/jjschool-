from django.contrib import admin
from .models import *

admin.site.register(Principal)
admin.site.register(Teacher)
admin.site.register(Student)
admin.site.register(Exam)
admin.site.register(TeacherSubjectAssignment)
admin.site.register(Classroom)


